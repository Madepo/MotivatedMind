package com.example.leitmotiv.ui.login

/**
 * Class exposing authenticated user details to the UI.
 */
internal class LoggedInUserView     //... other data fields that may be accessible to the UI
(val displayName: String?)